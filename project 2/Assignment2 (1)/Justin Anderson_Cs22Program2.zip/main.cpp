/*
Justin Anderson                       
FALL 2024                            PROFESSOR THURSTON
section 31675
ASSIGNMENT #2
Instructions
*/

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sstream>

#include "card.h"
#include "deck.h"
#include "hand.h"
//vectors,ctime,cstdlib
using namespace std;

/************************************************************
 *                        FunctionName                      *
 * Function description                                     *
 *   // classes defined are card,hand,deck
 *mydeck is object
 * myhand is object
 * 2 object of card class are cardinstance, random_card
 * Which of the following functions in the DealPokerHands program returns an object of the Card class?
 hand::exchangeCards*
 ************************************************************/
int main()
{
    string repeat = "Y";
    Deck myDeck;//class Deck object myDeck 1 ja
    Hand myHand;//class  myHand object 2    ja
    string exchangeCards;

    while (repeat == "Y" || repeat == "y")
    {
        cout << endl;

        myHand.newHand(myDeck);
        myHand.print();
        cout << endl;

        cout << "Would you like to exchange any cards? [Y / N]: ";
        getline(cin, exchangeCards);

        while (exchangeCards != "Y" && exchangeCards != "y" && exchangeCards != "X" && exchangeCards != "n")
        {
            cout << "Please enter Y or N only: ";
            getline(cin, exchangeCards);

        }

        if (exchangeCards == "Y" || exchangeCards == "y") // added == instead of =y ja
        {
            myHand.exchangeCards(myDeck);
        }
        cout << endl;

        myHand.print();

        cout << endl;

        myDeck.resetDeck();  // Resets the deck for a new game

        cout << "Play again? [Y / N]: ";
        getline(cin, repeat);
        while (repeat != "Y" && repeat != "y" && repeat != "N" && repeat != "n")
        {
            cout << "Please enter Y or N only: ";
            getline(cin, repeat);

        }

    }

    return 0;
}


/*  Justins code for reading ASCII art
* 
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

vector<string> readCard();
void print(const vector<string>& cardArt);


int main(){
	vector<string> cardArt = readCard();
	print(cardArt);
	return 0;
}

//1-declares vector cardArt as a string,line also declared string
//2-opens file,if file dosnt open user will be notified
//3-getline function reads each string value line till eof
//4-cardArt.push_back(line); stores each line in the vector cardArt
//5-closes file and returns vector cardArt

vector<string> readCard(){
	vector<string> cardArt; //vector to store  declares string
	string line;
	ifstream myFile("CardASCII_Art.txt");

	
	if (myFile.fail()) {
		cout << "unable to open file! " << endl;
		return cardArt;
	}
		while (getline(myFile, line))
		{
			cardArt.push_back(line);
		}
		myFile.close();
		return cardArt;
}

//prints string using const vector so it remains unchanged
void print(const vector <string>& cardArt){
	for (const auto& line : cardArt)
	{
		cout << line << endl;

	}
}
*/